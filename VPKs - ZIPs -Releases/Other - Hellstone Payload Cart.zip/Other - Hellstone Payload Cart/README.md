Note: Make sure to temporarily remove your Fire Overlay Fix for taking a screenshot for this payload, as the ghost model uses the fire overlay in-game!

Instructions:

Load props_vehicles/mining_car_metal.mdl as your main model.

Load these as submodels:

props_2fort/corrugated_metal002.mdl<br>
props_2fort/corrugated_metal002_2.mdl<br>
props_halloween/ghost.mdl